package com.bazardigital;

import com.bazardigital.app.ContextoBazar;
import com.bazardigital.ui.console.ConsolaBazar;
import com.bazardigital.ui.gui.VentanaBazar;

/** Punto de entrada. Sin argumentos abre la consola; con {@code --gui} abre la interfaz gráfica. */
public class Main {
    public static void main(String[] args) {
        ContextoBazar contexto = new ContextoBazar();
        if (args.length > 0 && args[0].equals("--gui")) {
            VentanaBazar.mostrar(contexto);
        } else {
            new ConsolaBazar(contexto, System.in, System.out).iniciar();
        }
    }
}
