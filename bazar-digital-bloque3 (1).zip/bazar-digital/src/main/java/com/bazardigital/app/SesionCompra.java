package com.bazardigital.app;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import com.bazardigital.domain.decorator.EmpaqueRegalo;
import com.bazardigital.domain.decorator.EnvioExpress;
import com.bazardigital.domain.decorator.GarantiaExtendida;
import com.bazardigital.domain.model.Carrito;
import com.bazardigital.domain.model.Cliente;
import com.bazardigital.domain.model.EntregaDigital;
import com.bazardigital.domain.model.EntregaDomicilio;
import com.bazardigital.domain.model.EntregaRetiro;
import com.bazardigital.domain.model.Factura;
import com.bazardigital.domain.model.LineaCarrito;
import com.bazardigital.domain.model.ModalidadEntrega;
import com.bazardigital.domain.model.Pedido;
import com.bazardigital.domain.model.Producto;
import com.bazardigital.domain.model.ProductoDigital;
import com.bazardigital.domain.observer.EstadoPedido;
import com.bazardigital.domain.strategy.descuento.CalculadoraDescuentos;
import com.bazardigital.domain.strategy.descuento.DescuentoClienteFrecuente;
import com.bazardigital.domain.strategy.descuento.DescuentoCupon;
import com.bazardigital.domain.strategy.descuento.DescuentoPorCantidad;
import com.bazardigital.domain.strategy.descuento.DescuentoTemporada;
import com.bazardigital.domain.strategy.descuento.EstrategiaDescuento;
import com.bazardigital.domain.strategy.descuento.ResultadoDescuento;
import com.bazardigital.domain.strategy.pago.AutorizacionTarjeta;
import com.bazardigital.domain.strategy.pago.DatosPago;
import com.bazardigital.domain.strategy.pago.EstrategiaPago;
import com.bazardigital.domain.strategy.pago.PagoContraEntrega;
import com.bazardigital.domain.strategy.pago.PagoTarjeta;
import com.bazardigital.domain.strategy.pago.PagoTransferencia;
import com.bazardigital.domain.strategy.pago.ReferenciaTransferencia;

/**
 * Caso de uso "comprar": reúne carrito, extras, descuentos, pago, inventario y seguimiento.
 * Lo comparten la consola y la GUI para no duplicar lógica de negocio en las interfaces.
 */
public class SesionCompra {
    public enum Extra { GARANTIA, EMPAQUE, EXPRESS }
    public enum Entrega { DOMICILIO, RETIRO }
    public enum MedioPago { TARJETA, TRANSFERENCIA, CONTRA_ENTREGA }

    public static final String CUPON_VALIDO = "BAZAR10";
    static final double PORCENTAJE_GARANTIA = 0.10;
    static final double COSTO_EMPAQUE = 5000;
    static final double COSTO_EXPRESS = 12000;

    private final ContextoBazar ctx;
    private final Cliente cliente;
    private final Carrito carrito = new Carrito();
    private boolean clienteFrecuente;
    private String cupon = "";

    public SesionCompra(ContextoBazar ctx, Cliente cliente) {
        this.ctx = Objects.requireNonNull(ctx);
        this.cliente = Objects.requireNonNull(cliente);
    }

    public Cliente getCliente() { return cliente; }
    public Carrito getCarrito() { return carrito; }
    public boolean isClienteFrecuente() { return clienteFrecuente; }
    public void setClienteFrecuente(boolean valor) { this.clienteFrecuente = valor; }
    public void setCupon(String cupon) { this.cupon = cupon == null ? "" : cupon.trim(); }
    public String getCupon() { return cupon; }

    // ---------------------------------------------------------------- carrito

    public void agregar(String productoId, int cantidad, Set<Extra> extras) {
        Producto producto = ctx.getProductos().findById(productoId)
                .orElseThrow(() -> new IllegalArgumentException("El producto no existe: " + productoId));
        if (!extras.isEmpty() && producto instanceof ProductoDigital) {
            throw new IllegalArgumentException("Los productos digitales no admiten extras");
        }
        Producto decorado = producto;
        if (extras.contains(Extra.GARANTIA)) {
            decorado = new GarantiaExtendida(decorado, producto.getPrecio() * PORCENTAJE_GARANTIA);
        }
        if (extras.contains(Extra.EMPAQUE)) {
            decorado = new EmpaqueRegalo(decorado, COSTO_EMPAQUE);
        }
        if (extras.contains(Extra.EXPRESS)) {
            decorado = new EnvioExpress(decorado, COSTO_EXPRESS);
        }
        ctx.getServicioCarrito().agregarProducto(carrito, decorado, cantidad);
    }

    public void quitar(String productoId) {
        ctx.getServicioCarrito().quitarProducto(carrito, productoId);
    }

    // --------------------------------------------------------------- resumen

    public ResumenCompra resumen(Entrega entrega) {
        List<ResumenCompra.Linea> lineas = new ArrayList<>();
        for (LineaCarrito l : carrito.getLineas()) {
            Producto p = l.getProducto();
            lineas.add(new ResumenCompra.Linea(p.getId(), p.getNombre() + " (" + p.getDescripcion() + ")",
                    l.getCantidad(), p.getPrecio(), l.calcularSubtotal()));
        }
        double subtotal = carrito.calcularSubtotal();
        ResultadoDescuento rd = CalculadoraDescuentos.calcular(subtotal, carrito.getCantidadTotal(),
                descuentosActivos());
        ModalidadEntrega modalidad = modalidad(entrega);
        double total = subtotal - rd.getMonto() + modalidad.getCostoAdicional();
        return new ResumenCompra(lineas, subtotal, rd.getMonto(), rd.getDescuentosAplicados(),
                modalidad.getNombre(), modalidad.getCostoAdicional(), total);
    }

    // ----------------------------------------------------------------- pago

    /**
     * Cierra la compra. {@code dato} es el número de tarjeta (16 dígitos; los que terminan en
     * 0000 simulan un rechazo) o la referencia de la transferencia; se ignora en contra entrega.
     */
    public Factura pagar(Entrega entrega, MedioPago medio, String dato) {
        ModalidadEntrega modalidad = modalidad(entrega);
        if (medio == MedioPago.CONTRA_ENTREGA && modalidad instanceof EntregaDigital) {
            throw new IllegalArgumentException("Un pedido solo digital no admite pago contra entrega");
        }
        ctx.getInventario().verificarDisponibilidad(carrito);

        Factura factura = ctx.getCheckout().cerrarPedido(cliente, carrito, modalidad,
                descuentosActivos(), estrategia(medio), datosPago(medio, dato));

        Pedido pedido = factura.getPedido();
        ctx.getInventario().descontarPedido(pedido);
        ctx.getSeguimiento().registrar(pedido);
        ctx.getSeguimiento().cambiarEstado(pedido.getId(),
                medio == MedioPago.CONTRA_ENTREGA ? EstadoPedido.EN_PREPARACION : EstadoPedido.PAGADO);
        return factura;
    }

    /** Historial de pedidos del cliente, del más reciente al más antiguo. */
    public List<Factura> historial() {
        List<Factura> facturas = new ArrayList<>();
        for (Pedido p : ctx.getPedidos().findAll()) {
            if (p.getCliente().getId().equals(cliente.getId())) {
                ctx.getCheckout().buscarFacturaPorPedido(p.getId()).ifPresent(facturas::add);
            }
        }
        facturas.sort((a, b) -> b.getFechaEmision().compareTo(a.getFechaEmision()));
        return facturas;
    }

    // -------------------------------------------------------------- helpers

    private List<EstrategiaDescuento> descuentosActivos() {
        List<EstrategiaDescuento> lista = new ArrayList<>();
        lista.add(new DescuentoPorCantidad(3, 5));
        lista.add(new DescuentoTemporada(5));
        lista.add(new DescuentoClienteFrecuente(clienteFrecuente, 5));
        if (!cupon.isBlank()) {
            lista.add(new DescuentoCupon(CUPON_VALIDO, cupon, 10));
        }
        return lista;
    }

    private ModalidadEntrega modalidad(Entrega entrega) {
        boolean soloDigital = !carrito.estaVacio() && carrito.getLineas().stream()
                .allMatch(l -> l.getProducto() instanceof ProductoDigital);
        if (soloDigital) {
            return new EntregaDigital();
        }
        return entrega == Entrega.RETIRO ? new EntregaRetiro() : new EntregaDomicilio();
    }

    private static EstrategiaPago estrategia(MedioPago medio) {
        return switch (medio) {
            case TARJETA -> new PagoTarjeta();
            case TRANSFERENCIA -> new PagoTransferencia();
            case CONTRA_ENTREGA -> new PagoContraEntrega();
        };
    }

    private static DatosPago datosPago(MedioPago medio, String dato) {
        return switch (medio) {
            case TARJETA -> {
                String numero = dato == null ? "" : dato.replaceAll("[\\s-]", "");
                if (!numero.matches("\\d{16}")) {
                    throw new IllegalArgumentException("El número de tarjeta debe tener 16 dígitos");
                }
                yield new AutorizacionTarjeta("AUTH-" + numero.substring(12) + "-"
                        + System.currentTimeMillis() % 100000, !numero.endsWith("0000"));
            }
            case TRANSFERENCIA -> new ReferenciaTransferencia(dato);
            case CONTRA_ENTREGA -> null;
        };
    }
}
