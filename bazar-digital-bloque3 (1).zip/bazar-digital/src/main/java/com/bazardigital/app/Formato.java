package com.bazardigital.app;

import java.text.NumberFormat;
import java.util.Locale;

import com.bazardigital.domain.model.ComboBazar;
import com.bazardigital.domain.model.Producto;
import com.bazardigital.domain.model.ProductoDigital;
import com.bazardigital.domain.model.ProductoFisico;

/** Utilidades de presentación compartidas por la consola y la GUI. */
public final class Formato {
    private static final Locale CO = Locale.forLanguageTag("es-CO");

    private Formato() {
    }

    public static String moneda(double valor) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(CO);
        nf.setMaximumFractionDigits(0);
        return nf.format(valor).replace('\u00a0', ' ');
    }

    /** Atributos propios de cada tipo de producto. */
    public static String atributos(Producto p) {
        if (p instanceof ProductoFisico f) {
            String talla = f.getTalla().isBlank() ? "" : ", talla " + f.getTalla();
            String marca = f.getMarca().isBlank() ? "" : "marca " + f.getMarca();
            return (marca + talla).replaceFirst("^, ", "");
        }
        if (p instanceof ProductoDigital d) {
            return "formato " + d.getFormato();
        }
        if (p instanceof ComboBazar c) {
            return c.getProductos().size() + " productos incluidos";
        }
        return "";
    }

    public static String stock(Producto p) {
        return p.getStock() == 0 ? "AGOTADO" : p.getStock() + " uds";
    }
}
