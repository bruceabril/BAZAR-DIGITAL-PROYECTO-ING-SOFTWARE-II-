package com.bazardigital.app;

import java.util.List;

/** Desglose del carrito listo para mostrar en cualquier interfaz (RNF02). */
public record ResumenCompra(List<Linea> lineas, double subtotal, double descuento,
                            List<String> descuentosAplicados, String modalidadEntrega,
                            double costoEntrega, double total) {

    public record Linea(String productoId, String descripcion, int cantidad,
                        double precioUnitario, double subtotal) {
    }
}
