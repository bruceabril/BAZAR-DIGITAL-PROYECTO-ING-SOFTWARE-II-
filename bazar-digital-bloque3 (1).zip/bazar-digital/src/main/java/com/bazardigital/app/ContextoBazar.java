package com.bazardigital.app;

import com.bazardigital.domain.factory.FabricaProductoFisico;
import com.bazardigital.domain.model.Categoria;
import com.bazardigital.domain.observer.BandejaNotificaciones;
import com.bazardigital.domain.observer.ObservadorAlertaStock;
import com.bazardigital.domain.observer.ObservadorEstadoPedido;
import com.bazardigital.repository.InMemoryPedidoRepository;
import com.bazardigital.repository.InMemoryProductoRepository;
import com.bazardigital.repository.PedidoRepository;
import com.bazardigital.repository.ProductoRepository;
import com.bazardigital.service.ServicioCarrito;
import com.bazardigital.service.ServicioCheckout;
import com.bazardigital.service.ServicioInventario;
import com.bazardigital.service.ServicioSeguimientoPedidos;

/**
 * Raíz de composición: crea y conecta repositorios, servicios y observadores.
 * La consola y la GUI usan esta misma instancia, de modo que comparten el núcleo de negocio.
 */
public class ContextoBazar {
    private final ProductoRepository productos = new InMemoryProductoRepository();
    private final PedidoRepository pedidos = new InMemoryPedidoRepository();
    private final BandejaNotificaciones bandeja = new BandejaNotificaciones();
    private final ObservadorAlertaStock alertaStock = new ObservadorAlertaStock(bandeja);
    private final ServicioInventario inventario = new ServicioInventario(productos, alertaStock);
    private final ServicioSeguimientoPedidos seguimiento = new ServicioSeguimientoPedidos();
    private final ServicioCarrito servicioCarrito = new ServicioCarrito(productos);
    private final ServicioCheckout checkout = new ServicioCheckout(pedidos);

    public ContextoBazar() {
        seguimiento.suscribir(new ObservadorEstadoPedido(bandeja));
        // Producto agotado de demostración para probar la alerta de stock (RF05).
        productos.save(new FabricaProductoFisico(Categoria.TECNOLOGIA, "", "Nova")
                .crearProducto("T002", "Smartwatch Nova", "Reloj inteligente (agotado)", 250000, 0));
    }

    public ProductoRepository getProductos() { return productos; }
    public PedidoRepository getPedidos() { return pedidos; }
    public BandejaNotificaciones getBandeja() { return bandeja; }
    public ServicioInventario getInventario() { return inventario; }
    public ServicioSeguimientoPedidos getSeguimiento() { return seguimiento; }
    public ServicioCarrito getServicioCarrito() { return servicioCarrito; }
    public ServicioCheckout getCheckout() { return checkout; }
}
