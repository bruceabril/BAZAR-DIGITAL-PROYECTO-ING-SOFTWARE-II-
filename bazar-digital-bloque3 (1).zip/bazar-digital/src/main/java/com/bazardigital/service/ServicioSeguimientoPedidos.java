package com.bazardigital.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.bazardigital.domain.model.Pedido;
import com.bazardigital.domain.observer.EstadoPedido;
import com.bazardigital.domain.observer.EventoPedido;
import com.bazardigital.domain.observer.Observador;
import com.bazardigital.domain.observer.Sujeto;

/**
 * Lleva el estado de cada pedido y publica un {@link EventoPedido} en cada transición
 * (rol Subject del patrón Observer).
 */
public class ServicioSeguimientoPedidos {
    private final Map<String, EstadoPedido> estados = new HashMap<>();
    private final Map<String, Pedido> pedidos = new HashMap<>();
    private final Sujeto<EventoPedido> sujeto = new Sujeto<>();

    public void suscribir(Observador<EventoPedido> observador) {
        sujeto.suscribir(observador);
    }

    public void desuscribir(Observador<EventoPedido> observador) {
        sujeto.desuscribir(observador);
    }

    /** Registra un pedido recién creado (estado CREADO). */
    public synchronized void registrar(Pedido pedido) {
        Objects.requireNonNull(pedido, "El pedido es obligatorio");
        estados.put(pedido.getId(), EstadoPedido.CREADO);
        pedidos.put(pedido.getId(), pedido);
    }

    public synchronized EstadoPedido consultarEstado(String pedidoId) {
        EstadoPedido estado = estados.get(pedidoId);
        if (estado == null) {
            throw new IllegalArgumentException("El pedido no está registrado: " + pedidoId);
        }
        return estado;
    }

    public void cambiarEstado(String pedidoId, EstadoPedido nuevo) {
        Objects.requireNonNull(nuevo, "El nuevo estado es obligatorio");
        EventoPedido evento;
        synchronized (this) {
            EstadoPedido actual = consultarEstado(pedidoId);
            if (!actual.puedePasarA(nuevo)) {
                throw new IllegalStateException("Transición no permitida: " + actual + " -> " + nuevo);
            }
            estados.put(pedidoId, nuevo);
            evento = new EventoPedido(pedidoId, pedidos.get(pedidoId).getCliente(), actual, nuevo);
        }
        sujeto.notificar(evento);
    }
}
