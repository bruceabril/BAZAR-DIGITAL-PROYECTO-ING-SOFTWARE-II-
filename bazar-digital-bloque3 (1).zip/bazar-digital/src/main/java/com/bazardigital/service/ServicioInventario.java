package com.bazardigital.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.bazardigital.domain.model.Carrito;
import com.bazardigital.domain.model.Cliente;
import com.bazardigital.domain.model.LineaCarrito;
import com.bazardigital.domain.model.Pedido;
import com.bazardigital.domain.model.Producto;
import com.bazardigital.domain.observer.EventoStock;
import com.bazardigital.domain.observer.Observador;
import com.bazardigital.domain.observer.ObservadorAlertaStock;
import com.bazardigital.domain.observer.Sujeto;
import com.bazardigital.repository.ProductoRepository;

/**
 * Gestiona el stock y publica un {@link EventoStock} cada vez que cambia (rol Subject
 * del patrón Observer). También administra las alertas de disponibilidad (RF05).
 */
public class ServicioInventario {
    private final ProductoRepository productoRepository;
    private final ObservadorAlertaStock alertas;
    private final Sujeto<EventoStock> sujeto = new Sujeto<>();

    public ServicioInventario(ProductoRepository productoRepository, ObservadorAlertaStock alertas) {
        this.productoRepository = Objects.requireNonNull(productoRepository);
        this.alertas = Objects.requireNonNull(alertas);
        this.sujeto.suscribir(alertas);
    }

    public void suscribir(Observador<EventoStock> observador) {
        sujeto.suscribir(observador);
    }

    public void desuscribir(Observador<EventoStock> observador) {
        sujeto.desuscribir(observador);
    }

    public int consultarStock(String productoId) {
        return buscar(productoId).getStock();
    }

    public List<Producto> productosAgotados() {
        return productoRepository.findAll().stream().filter(p -> p.getStock() == 0).toList();
    }

    /** Suma unidades al stock actual (reabastecimiento). */
    public synchronized void reabastecer(String productoId, int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad a reabastecer debe ser mayor que cero");
        }
        Producto producto = buscar(productoId);
        cambiarStock(producto, producto.getStock() + cantidad);
    }

    /** Fija el stock a un valor exacto. */
    public synchronized void ajustarStock(String productoId, int nuevoStock) {
        cambiarStock(buscar(productoId), nuevoStock);
    }

    /** Verifica, sin modificar nada, que el carrito completo tenga stock suficiente. */
    public synchronized void verificarDisponibilidad(Carrito carrito) {
        validarDisponibilidad(cantidadesPorProducto(carrito.getLineas().stream()
                .flatMap(l -> java.util.Collections.nCopies(l.getCantidad(), l.getProducto()).stream())
                .toList()));
    }

    /**
     * Descuenta del inventario los productos de un pedido confirmado. Es todo o nada:
     * si algún producto no alcanza, no se descuenta ninguno (RNF03).
     */
    public synchronized void descontarPedido(Pedido pedido) {
        Map<String, Integer> cantidades = cantidadesPorProducto(pedido.getProductos());
        validarDisponibilidad(cantidades);
        cantidades.forEach((id, cantidad) -> {
            Producto producto = buscar(id);
            cambiarStock(producto, producto.getStock() - cantidad);
        });
    }

    /**
     * Registra al cliente para avisarle cuando el producto vuelva a tener stock.
     * Solo tiene sentido para productos agotados.
     */
    public void suscribirAlertaStock(Cliente cliente, String productoId) {
        Objects.requireNonNull(cliente, "El cliente es obligatorio");
        Producto producto = buscar(productoId);
        if (producto.getStock() > 0) {
            throw new IllegalArgumentException(
                    "El producto aún tiene stock; solo se puede suscribir a productos agotados");
        }
        alertas.registrarInteresado(productoId, cliente);
    }

    private void cambiarStock(Producto producto, int nuevoStock) {
        int anterior = producto.getStock();
        producto.actualizarStock(nuevoStock);
        productoRepository.save(producto);
        if (anterior != nuevoStock) {
            sujeto.notificar(new EventoStock(producto.getId(), producto.getNombre(), anterior, nuevoStock));
        }
    }

    private void validarDisponibilidad(Map<String, Integer> cantidades) {
        cantidades.forEach((id, cantidad) -> {
            Producto producto = buscar(id);
            if (cantidad > producto.getStock()) {
                throw new IllegalArgumentException("Stock insuficiente para '" + producto.getNombre()
                        + "': solicitado " + cantidad + ", disponible " + producto.getStock());
            }
        });
    }

    private static Map<String, Integer> cantidadesPorProducto(List<Producto> productos) {
        Map<String, Integer> cantidades = new HashMap<>();
        for (Producto p : productos) {
            cantidades.merge(p.getId(), 1, Integer::sum);
        }
        return cantidades;
    }

    private Producto buscar(String productoId) {
        return productoRepository.findById(productoId)
                .orElseThrow(() -> new IllegalArgumentException("El producto no existe: " + productoId));
    }
}
