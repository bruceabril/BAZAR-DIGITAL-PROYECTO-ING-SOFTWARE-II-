package com.bazardigital.domain.observer;

import com.bazardigital.domain.model.Cliente;

/** Medio por el cual se entrega una notificación (correo, consola, bandeja...). */
public interface CanalNotificacion {
    void enviar(Cliente destinatario, String mensaje);
}
