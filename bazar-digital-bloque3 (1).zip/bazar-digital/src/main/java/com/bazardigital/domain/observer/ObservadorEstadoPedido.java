package com.bazardigital.domain.observer;

import java.util.Objects;

/** <b>ConcreteObserver</b> de {@link EventoPedido}: avisa al cliente del nuevo estado. */
public class ObservadorEstadoPedido implements Observador<EventoPedido> {
    private final CanalNotificacion canal;

    public ObservadorEstadoPedido(CanalNotificacion canal) {
        this.canal = Objects.requireNonNull(canal, "El canal es obligatorio");
    }

    @Override
    public void actualizar(EventoPedido evento) {
        canal.enviar(evento.cliente(), "Tu pedido " + resumirId(evento.pedidoId()) + " cambió de "
                + evento.estadoAnterior() + " a " + evento.estadoNuevo() + ".");
    }

    private static String resumirId(String id) {
        return "#" + (id.length() > 8 ? id.substring(0, 8) : id);
    }
}
