package com.bazardigital.domain.observer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.bazardigital.domain.model.Cliente;

/**
 * <b>ConcreteObserver</b> de {@link EventoStock}. Registra a los clientes interesados en
 * productos agotados y les avisa (una sola vez) cuando el producto vuelve a tener stock.
 */
public class ObservadorAlertaStock implements Observador<EventoStock> {
    private final CanalNotificacion canal;
    private final Map<String, Map<String, Cliente>> interesados = new HashMap<>();

    public ObservadorAlertaStock(CanalNotificacion canal) {
        this.canal = Objects.requireNonNull(canal, "El canal es obligatorio");
    }

    public synchronized void registrarInteresado(String productoId, Cliente cliente) {
        Objects.requireNonNull(productoId, "El producto es obligatorio");
        Objects.requireNonNull(cliente, "El cliente es obligatorio");
        interesados.computeIfAbsent(productoId, k -> new LinkedHashMap<>())
                .put(cliente.getId(), cliente);
    }

    public synchronized boolean estaRegistrado(String productoId, Cliente cliente) {
        return interesados.getOrDefault(productoId, Map.of()).containsKey(cliente.getId());
    }

    public synchronized int cantidadInteresados(String productoId) {
        return interesados.getOrDefault(productoId, Map.of()).size();
    }

    @Override
    public void actualizar(EventoStock evento) {
        if (!evento.esReabastecimiento()) {
            return;
        }
        List<Cliente> aAvisar;
        synchronized (this) {
            Map<String, Cliente> registrados = interesados.remove(evento.productoId());
            aAvisar = registrados == null ? List.of() : new ArrayList<>(registrados.values());
        }
        for (Cliente cliente : aAvisar) {
            canal.enviar(cliente, "Hola " + cliente.getNombre() + ": '" + evento.nombreProducto()
                    + "' ya tiene stock disponible (" + evento.stockNuevo() + " unidades).");
        }
    }
}
