package com.bazardigital.domain.observer;

import java.time.Instant;

import com.bazardigital.domain.model.Cliente;

/** Mensaje simulado enviado a un cliente. */
public record Notificacion(Cliente destinatario, String mensaje, Instant fecha) {
}
