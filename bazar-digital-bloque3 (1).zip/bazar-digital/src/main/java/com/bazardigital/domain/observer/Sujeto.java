package com.bazardigital.domain.observer;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Rol <b>Subject</b> del patrón Observer. Mantiene la lista de observadores y les
 * notifica cada evento. Un observador que falla no impide que los demás reciban el aviso.
 */
public class Sujeto<E> {
    private final List<Observador<E>> observadores = new CopyOnWriteArrayList<>();

    public void suscribir(Observador<E> observador) {
        Objects.requireNonNull(observador, "El observador es obligatorio");
        if (!observadores.contains(observador)) {
            observadores.add(observador);
        }
    }

    public void desuscribir(Observador<E> observador) {
        observadores.remove(observador);
    }

    public int cantidadObservadores() {
        return observadores.size();
    }

    public void notificar(E evento) {
        Objects.requireNonNull(evento, "El evento es obligatorio");
        for (Observador<E> observador : observadores) {
            try {
                observador.actualizar(evento);
            } catch (RuntimeException e) {
                // Un observador defectuoso no debe afectar al resto ni a la operación de negocio.
                System.err.println("Observador con error: " + e.getMessage());
            }
        }
    }
}
