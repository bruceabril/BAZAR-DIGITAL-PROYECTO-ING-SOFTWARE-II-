package com.bazardigital.domain.observer;

/** Evento publicado cuando cambia el stock de un producto. */
public record EventoStock(String productoId, String nombreProducto, int stockAnterior, int stockNuevo) {

    /** Un producto agotado que vuelve a tener existencias. */
    public boolean esReabastecimiento() {
        return stockAnterior == 0 && stockNuevo > 0;
    }
}
