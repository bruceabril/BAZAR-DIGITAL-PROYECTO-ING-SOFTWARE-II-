package com.bazardigital.domain.observer;

import com.bazardigital.domain.model.Cliente;

/** Evento publicado cuando cambia el estado de un pedido. */
public record EventoPedido(String pedidoId, Cliente cliente, EstadoPedido estadoAnterior,
                           EstadoPedido estadoNuevo) {
}
