package com.bazardigital.domain.observer;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.bazardigital.domain.model.Cliente;

/** Canal simulado: guarda las notificaciones en memoria para que las UIs las muestren. */
public class BandejaNotificaciones implements CanalNotificacion {
    private final List<Notificacion> notificaciones = new ArrayList<>();

    @Override
    public synchronized void enviar(Cliente destinatario, String mensaje) {
        notificaciones.add(new Notificacion(Objects.requireNonNull(destinatario),
                Objects.requireNonNull(mensaje), Instant.now()));
    }

    public synchronized List<Notificacion> getNotificaciones() {
        return List.copyOf(notificaciones);
    }

    public synchronized List<Notificacion> getNotificaciones(String clienteId) {
        return notificaciones.stream()
                .filter(n -> n.destinatario().getId().equals(clienteId))
                .toList();
    }
}
