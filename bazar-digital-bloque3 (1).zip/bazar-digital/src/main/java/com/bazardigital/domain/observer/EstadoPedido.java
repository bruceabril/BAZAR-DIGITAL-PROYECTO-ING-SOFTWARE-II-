package com.bazardigital.domain.observer;

import java.util.Set;

/** Ciclo de vida de un pedido con las transiciones permitidas. */
public enum EstadoPedido {
    CREADO, PAGADO, EN_PREPARACION, ENVIADO, ENTREGADO, CANCELADO;

    public Set<EstadoPedido> siguientesPermitidos() {
        return switch (this) {
            case CREADO -> Set.of(PAGADO, EN_PREPARACION, CANCELADO); // contra entrega pasa directo a preparación
            case PAGADO -> Set.of(EN_PREPARACION, CANCELADO);
            case EN_PREPARACION -> Set.of(ENVIADO, CANCELADO);
            case ENVIADO -> Set.of(ENTREGADO);
            case ENTREGADO, CANCELADO -> Set.of();
        };
    }

    public boolean puedePasarA(EstadoPedido destino) {
        return siguientesPermitidos().contains(destino);
    }
}
