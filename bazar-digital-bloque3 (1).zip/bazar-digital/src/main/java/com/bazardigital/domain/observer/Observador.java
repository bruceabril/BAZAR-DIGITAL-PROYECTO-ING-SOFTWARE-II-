package com.bazardigital.domain.observer;

/**
 * Rol <b>Observer</b> del patrón Observer: recibe los eventos de tipo {@code E}
 * que publica un {@link Sujeto}.
 */
@FunctionalInterface
public interface Observador<E> {
    void actualizar(E evento);
}
