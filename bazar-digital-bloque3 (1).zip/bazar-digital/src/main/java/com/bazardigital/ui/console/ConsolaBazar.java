package com.bazardigital.ui.console;

import java.io.InputStream;
import java.io.PrintStream;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.EnumSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;

import com.bazardigital.app.ContextoBazar;
import com.bazardigital.app.Formato;
import com.bazardigital.app.ResumenCompra;
import com.bazardigital.app.SesionCompra;
import com.bazardigital.app.SesionCompra.Entrega;
import com.bazardigital.app.SesionCompra.Extra;
import com.bazardigital.app.SesionCompra.MedioPago;
import com.bazardigital.domain.model.Categoria;
import com.bazardigital.domain.model.Cliente;
import com.bazardigital.domain.model.Factura;
import com.bazardigital.domain.model.Producto;
import com.bazardigital.domain.observer.EstadoPedido;
import com.bazardigital.domain.observer.Notificacion;

/** Interfaz por consola: solo captura entradas y muestra resultados; la lógica está en el núcleo. */
public class ConsolaBazar {
    private static final DateTimeFormatter HORA =
            DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault());

    private final ContextoBazar ctx;
    private final Scanner in;
    private final PrintStream out;
    private SesionCompra sesion;

    public ConsolaBazar(ContextoBazar ctx, InputStream entrada, PrintStream salida) {
        this.ctx = ctx;
        this.in = new Scanner(entrada);
        this.out = salida;
    }

    public void iniciar() {
        out.println("=== BAZAR DIGITAL ===");
        String nombre = pedir("Tu nombre");
        String correo = pedir("Tu correo");
        sesion = new SesionCompra(ctx, new Cliente("C-" + Math.abs(correo.hashCode()), nombre, correo));
        try {
            boolean salir = false;
            while (!salir) {
                mostrarMenu();
                salir = ejecutar(pedir("Opción"));
            }
        } catch (NoSuchElementException finEntrada) {
            // Entrada cerrada: termina la sesión.
        }
        out.println("¡Hasta pronto!");
    }

    private void mostrarMenu() {
        out.println();
        out.println("--- Menú (" + sesion.getCliente().getNombre() + ") ---");
        out.println(" 1. Ver catálogo        6. Pagar");
        out.println(" 2. Agregar al carrito  7. Mis pedidos");
        out.println(" 3. Ver carrito         8. Alerta de stock");
        out.println(" 4. Quitar del carrito  9. Notificaciones");
        out.println(" 5. Cupón / cliente frecuente");
        out.println(" 10. Simulación: reabastecer / avanzar pedido");
        out.println(" 0. Salir");
    }

    private boolean ejecutar(String opcion) {
        try {
            switch (opcion) {
                case "1" -> verCatalogo();
                case "2" -> agregar();
                case "3" -> verCarrito(Entrega.DOMICILIO);
                case "4" -> { sesion.quitar(pedir("Id del producto")); out.println("Producto quitado."); }
                case "5" -> descuentos();
                case "6" -> pagar();
                case "7" -> misPedidos();
                case "8" -> alertaStock();
                case "9" -> notificaciones();
                case "10" -> simulacion();
                case "0" -> { return true; }
                default -> out.println("Opción no válida.");
            }
        } catch (IllegalArgumentException | IllegalStateException e) {
            out.println("⚠ " + e.getMessage());
        }
        return false;
    }

    private void verCatalogo() {
        out.println("Categorías: " + List.of(Categoria.values()) + " (vacío = todas)");
        String texto = in.nextLine().trim();
        List<Producto> productos = texto.isEmpty()
                ? ctx.getProductos().findAll()
                : ctx.getProductos().findByCategoria(Categoria.valueOf(texto.toUpperCase()));
        out.printf("%-6s %-28s %-12s %12s  %-10s %s%n", "ID", "Producto", "Categoría", "Precio", "Stock", "Atributos");
        for (Producto p : productos) {
            out.printf("%-6s %-28s %-12s %12s  %-10s %s%n", p.getId(), p.getNombre(), p.getCategoria(),
                    Formato.moneda(p.getPrecio()), Formato.stock(p), Formato.atributos(p));
        }
    }

    private void agregar() {
        String id = pedir("Id del producto");
        int cantidad = Integer.parseInt(pedir("Cantidad"));
        Set<Extra> extras = EnumSet.noneOf(Extra.class);
        if (si("¿Garantía extendida (+10%)?")) extras.add(Extra.GARANTIA);
        if (si("¿Empaque de regalo (+" + Formato.moneda(5000) + ")?")) extras.add(Extra.EMPAQUE);
        if (si("¿Envío express (+" + Formato.moneda(12000) + ")?")) extras.add(Extra.EXPRESS);
        sesion.agregar(id, cantidad, extras);
        out.println("Agregado al carrito.");
    }

    private void verCarrito(Entrega entrega) {
        if (sesion.getCarrito().estaVacio()) {
            out.println("El carrito está vacío.");
            return;
        }
        ResumenCompra r = sesion.resumen(entrega);
        for (ResumenCompra.Linea l : r.lineas()) {
            out.printf(" %-5s x%d  %s  = %s%n", l.productoId(), l.cantidad(), l.descripcion(),
                    Formato.moneda(l.subtotal()));
        }
        out.println("Subtotal:  " + Formato.moneda(r.subtotal()));
        out.println("Descuento: -" + Formato.moneda(r.descuento())
                + (r.descuentosAplicados().isEmpty() ? "" : "  " + r.descuentosAplicados()));
        out.println("Entrega (" + r.modalidadEntrega() + "): " + Formato.moneda(r.costoEntrega()));
        out.println("TOTAL:     " + Formato.moneda(r.total()));
    }

    private void descuentos() {
        sesion.setClienteFrecuente(si("¿Eres cliente frecuente?"));
        sesion.setCupon(pedir("Cupón (vacío = ninguno; prueba " + SesionCompra.CUPON_VALIDO + ")", true));
        verCarrito(Entrega.DOMICILIO);
    }

    private void pagar() {
        if (sesion.getCarrito().estaVacio()) {
            out.println("El carrito está vacío.");
            return;
        }
        Entrega entrega = pedir("Entrega: 1) Domicilio  2) Retiro en el bazar (los productos digitales se entregan por correo)")
                .equals("2") ? Entrega.RETIRO : Entrega.DOMICILIO;
        verCarrito(entrega);
        MedioPago medio = switch (pedir("Pago: 1) Tarjeta  2) Transferencia  3) Contra entrega")) {
            case "1" -> MedioPago.TARJETA;
            case "2" -> MedioPago.TRANSFERENCIA;
            case "3" -> MedioPago.CONTRA_ENTREGA;
            default -> throw new IllegalArgumentException("Medio de pago no válido");
        };
        String dato = switch (medio) {
            case TARJETA -> pedir("Número de tarjeta (16 dígitos; terminado en 0000 = rechazada)");
            case TRANSFERENCIA -> pedir("Referencia de la transferencia");
            case CONTRA_ENTREGA -> "";
        };
        if (!si("¿Confirmar el pago?")) {
            out.println("Compra cancelada.");
            return;
        }
        imprimirFactura(sesion.pagar(entrega, medio, dato));
    }

    private void imprimirFactura(Factura f) {
        out.println();
        out.println("========== FACTURA ==========");
        out.println("Factura: " + f.getId());
        out.println("Pedido:  " + f.getPedido().getId());
        out.println("Cliente: " + f.getPedido().getCliente().getNombre());
        f.getPedido().getProductos().stream()
                .collect(java.util.stream.Collectors.groupingBy(p -> p, java.util.LinkedHashMap::new,
                        java.util.stream.Collectors.counting()))
                .forEach((p, n) -> out.println(" - " + n + " x " + p.getNombre() + " ("
                        + p.getDescripcion() + ") " + Formato.moneda(p.getPrecio()) + " c/u"));
        out.println("Subtotal:  " + Formato.moneda(f.getSubtotal()));
        out.println("Descuento: -" + Formato.moneda(f.getDescuento()));
        out.println("Entrega:   " + Formato.moneda(f.getCostoEntrega()));
        out.println("TOTAL:     " + Formato.moneda(f.getTotal()));
        out.println("Pago: " + f.getPago().getMedioPago() + " ref. " + f.getPago().getReferencia());
        out.println("=============================");
    }

    private void misPedidos() {
        List<Factura> facturas = sesion.historial();
        if (facturas.isEmpty()) {
            out.println("Aún no tienes pedidos.");
        }
        for (Factura f : facturas) {
            out.printf("Pedido %s | %s | %s | %s%n", f.getPedido().getId().substring(0, 8),
                    Formato.moneda(f.getTotal()), f.getPago().getMedioPago(),
                    ctx.getSeguimiento().consultarEstado(f.getPedido().getId()));
        }
    }

    private void alertaStock() {
        List<Producto> agotados = ctx.getInventario().productosAgotados();
        if (agotados.isEmpty()) {
            out.println("No hay productos agotados.");
            return;
        }
        agotados.forEach(p -> out.println(" " + p.getId() + " - " + p.getNombre()));
        ctx.getInventario().suscribirAlertaStock(sesion.getCliente(), pedir("Id del producto agotado"));
        out.println("Te avisaremos cuando vuelva a tener stock.");
    }

    private void notificaciones() {
        List<Notificacion> lista = ctx.getBandeja().getNotificaciones(sesion.getCliente().getId());
        if (lista.isEmpty()) {
            out.println("Sin notificaciones.");
        }
        lista.forEach(n -> out.println("[" + HORA.format(n.fecha()) + "] " + n.mensaje()));
    }

    private void simulacion() {
        switch (pedir("1) Reabastecer producto  2) Avanzar estado de un pedido")) {
            case "1" -> {
                String id = pedir("Id del producto");
                ctx.getInventario().reabastecer(id, Integer.parseInt(pedir("Unidades")));
                out.println("Stock actual: " + ctx.getInventario().consultarStock(id));
            }
            case "2" -> {
                List<Factura> facturas = sesion.historial();
                if (facturas.isEmpty()) {
                    out.println("No tienes pedidos.");
                    return;
                }
                String id = facturas.get(0).getPedido().getId();
                EstadoPedido actual = ctx.getSeguimiento().consultarEstado(id);
                out.println("Último pedido en estado " + actual + ". Siguientes: " + actual.siguientesPermitidos());
                ctx.getSeguimiento().cambiarEstado(id, EstadoPedido.valueOf(pedir("Nuevo estado").toUpperCase()));
            }
            default -> out.println("Opción no válida.");
        }
    }

    private String pedir(String etiqueta) {
        return pedir(etiqueta, false);
    }

    private String pedir(String etiqueta, boolean permitirVacio) {
        String linea;
        do {
            out.print(etiqueta + ": ");
            out.flush();
            linea = in.nextLine().trim();
        } while (linea.isEmpty() && !permitirVacio);
        return linea;
    }

    private boolean si(String pregunta) {
        return pedir(pregunta + " (s/n)").toLowerCase().startsWith("s");
    }
}
