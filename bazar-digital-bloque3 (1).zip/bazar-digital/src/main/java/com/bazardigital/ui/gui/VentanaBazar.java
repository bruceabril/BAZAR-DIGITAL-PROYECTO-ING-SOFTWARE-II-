package com.bazardigital.ui.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import com.bazardigital.app.ContextoBazar;
import com.bazardigital.app.Formato;
import com.bazardigital.app.ResumenCompra;
import com.bazardigital.app.SesionCompra;
import com.bazardigital.app.SesionCompra.Entrega;
import com.bazardigital.app.SesionCompra.Extra;
import com.bazardigital.app.SesionCompra.MedioPago;
import com.bazardigital.domain.model.Categoria;
import com.bazardigital.domain.model.Cliente;
import com.bazardigital.domain.model.Factura;
import com.bazardigital.domain.model.Producto;
import com.bazardigital.domain.observer.EstadoPedido;

/** Interfaz gráfica sencilla (Swing) sobre el mismo núcleo que usa la consola. */
public class VentanaBazar extends JFrame {
    private static final DateTimeFormatter HORA =
            DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault());

    private final ContextoBazar ctx;
    private final SesionCompra sesion;

    private final JComboBox<String> filtroCategoria = new JComboBox<>();
    private final DefaultTableModel modeloCatalogo = modelo("ID", "Producto", "Categoría", "Precio", "Stock", "Atributos");
    private final JTable tablaCatalogo = new JTable(modeloCatalogo);
    private final JSpinner cantidad = new JSpinner(new SpinnerNumberModel(1, 1, 99, 1));
    private final JCheckBox chkGarantia = new JCheckBox("Garantía extendida (+10%)");
    private final JCheckBox chkEmpaque = new JCheckBox("Empaque de regalo (+" + Formato.moneda(5000) + ")");
    private final JCheckBox chkExpress = new JCheckBox("Envío express (+" + Formato.moneda(12000) + ")");

    private final DefaultTableModel modeloCarrito = modelo("ID", "Producto", "Cant.", "Precio unit.", "Subtotal");
    private final JTable tablaCarrito = new JTable(modeloCarrito);
    private final JCheckBox chkFrecuente = new JCheckBox("Cliente frecuente");
    private final JTextField campoCupon = new JTextField(10);
    private final JComboBox<Entrega> comboEntrega = new JComboBox<>(Entrega.values());
    private final JComboBox<MedioPago> comboPago = new JComboBox<>(MedioPago.values());
    private final JTextField campoDatoPago = new JTextField(18);
    private final JTextArea areaResumen = new JTextArea(9, 40);

    private final DefaultTableModel modeloPedidos = modelo("Pedido", "Total", "Pago", "Estado");
    private final JTable tablaPedidos = new JTable(modeloPedidos);
    private List<Factura> facturasMostradas = List.of();
    private final JTextArea areaNotificaciones = new JTextArea();

    public VentanaBazar(ContextoBazar ctx, Cliente cliente) {
        super("Bazar Digital - " + cliente.getNombre());
        this.ctx = ctx;
        this.sesion = new SesionCompra(ctx, cliente);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Catálogo", panelCatalogo());
        tabs.addTab("Carrito y pago", panelCarrito());
        tabs.addTab("Mis pedidos", panelPedidos());
        tabs.addTab("Notificaciones", new JScrollPane(areaNotificaciones));
        areaNotificaciones.setEditable(false);
        add(tabs);
        for (JTable t : new JTable[] {tablaCatalogo, tablaCarrito}) {
            t.getColumnModel().getColumn(0).setMaxWidth(70);
        }

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 560);
        setLocationRelativeTo(null);
        refrescar();
    }

    public static void mostrar(ContextoBazar ctx) {
        SwingUtilities.invokeLater(() -> {
            String nombre = JOptionPane.showInputDialog(null, "Tu nombre:", "Cliente Demo");
            if (nombre == null || nombre.isBlank()) {
                nombre = "Cliente Demo";
            }
            String correo = JOptionPane.showInputDialog(null, "Tu correo:", "cliente@bazar.com");
            if (correo == null || correo.isBlank()) {
                correo = "cliente@bazar.com";
            }
            new VentanaBazar(ctx, new Cliente("C-" + Math.abs(correo.hashCode()), nombre.trim(), correo.trim()))
                    .setVisible(true);
        });
    }

    // ------------------------------------------------------------- paneles

    private JPanel panelCatalogo() {
        filtroCategoria.addItem("Todas");
        for (Categoria c : Categoria.values()) {
            filtroCategoria.addItem(c.name());
        }
        filtroCategoria.addActionListener(e -> cargarCatalogo());

        JPanel arriba = new JPanel(new FlowLayout(FlowLayout.LEFT));
        arriba.add(new JLabel("Categoría:"));
        arriba.add(filtroCategoria);

        JButton agregar = new JButton("Agregar al carrito");
        agregar.addActionListener(e -> accion(() -> {
            sesion.agregar(idSeleccionado(tablaCatalogo), (Integer) cantidad.getValue(), extrasMarcados());
            refrescar();
        }));
        JButton alerta = new JButton("Avisarme cuando haya stock");
        alerta.addActionListener(e -> accion(() -> {
            ctx.getInventario().suscribirAlertaStock(sesion.getCliente(), idSeleccionado(tablaCatalogo));
            info("Te avisaremos en la pestaña Notificaciones cuando el producto tenga stock.");
        }));
        JButton reabastecer = new JButton("Reabastecer (simulación)");
        reabastecer.addActionListener(e -> accion(() -> {
            String uds = JOptionPane.showInputDialog(this, "Unidades a agregar:", "10");
            if (uds != null) {
                ctx.getInventario().reabastecer(idSeleccionado(tablaCatalogo), Integer.parseInt(uds.trim()));
                refrescar();
            }
        }));

        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        abajo.add(new JLabel("Cantidad:"));
        abajo.add(cantidad);
        abajo.add(chkGarantia);
        abajo.add(chkEmpaque);
        abajo.add(chkExpress);
        abajo.add(agregar);
        abajo.add(alerta);
        abajo.add(reabastecer);

        JPanel p = new JPanel(new BorderLayout(6, 6));
        p.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        p.add(arriba, BorderLayout.NORTH);
        p.add(new JScrollPane(tablaCatalogo), BorderLayout.CENTER);
        p.add(abajo, BorderLayout.SOUTH);
        return p;
    }

    private JPanel panelCarrito() {
        JButton quitar = new JButton("Quitar producto");
        quitar.addActionListener(e -> accion(() -> {
            sesion.quitar(idSeleccionado(tablaCarrito));
            refrescar();
        }));
        JButton aplicar = new JButton("Aplicar");
        aplicar.addActionListener(e -> refrescar());
        chkFrecuente.addActionListener(e -> refrescar());
        comboEntrega.addActionListener(e -> refrescar());
        JButton pagar = new JButton("Pagar");
        pagar.addActionListener(e -> accion(this::pagar));

        JPanel opciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        opciones.add(chkFrecuente);
        opciones.add(new JLabel("Cupón (" + SesionCompra.CUPON_VALIDO + "):"));
        opciones.add(campoCupon);
        opciones.add(aplicar);
        opciones.add(new JLabel("Entrega:"));
        opciones.add(comboEntrega);

        JPanel pago = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pago.add(new JLabel("Pago:"));
        pago.add(comboPago);
        pago.add(new JLabel("Tarjeta (16 díg., 0000 = rechazo) / referencia:"));
        pago.add(campoDatoPago);
        pago.add(pagar);
        pago.add(quitar);

        areaResumen.setEditable(false);
        areaResumen.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));

        JPanel sur = new JPanel(new BorderLayout());
        sur.add(opciones, BorderLayout.NORTH);
        sur.add(new JScrollPane(areaResumen), BorderLayout.CENTER);
        sur.add(pago, BorderLayout.SOUTH);

        JPanel p = new JPanel(new BorderLayout(6, 6));
        p.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        p.add(new JScrollPane(tablaCarrito), BorderLayout.CENTER);
        p.add(sur, BorderLayout.SOUTH);
        return p;
    }

    private JPanel panelPedidos() {
        JComboBox<EstadoPedido> siguiente = new JComboBox<>(EstadoPedido.values());
        JButton cambiar = new JButton("Cambiar estado (simulación)");
        cambiar.addActionListener(e -> accion(() -> {
            int fila = tablaPedidos.getSelectedRow();
            if (fila < 0) {
                throw new IllegalArgumentException("Selecciona un pedido");
            }
            ctx.getSeguimiento().cambiarEstado(facturasMostradas.get(fila).getPedido().getId(),
                    (EstadoPedido) siguiente.getSelectedItem());
            refrescar();
        }));
        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        abajo.add(new JLabel("Nuevo estado:"));
        abajo.add(siguiente);
        abajo.add(cambiar);

        JPanel p = new JPanel(new BorderLayout(6, 6));
        p.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        p.add(new JScrollPane(tablaPedidos), BorderLayout.CENTER);
        p.add(abajo, BorderLayout.SOUTH);
        return p;
    }

    // -------------------------------------------------------------- acciones

    private void pagar() {
        sesion.setCupon(campoCupon.getText());
        Factura f = sesion.pagar((Entrega) comboEntrega.getSelectedItem(),
                (MedioPago) comboPago.getSelectedItem(), campoDatoPago.getText());
        campoDatoPago.setText("");
        refrescar();
        JTextArea texto = new JTextArea(String.format(
                "Factura %s%nPedido %s%n%nSubtotal:  %s%nDescuento: -%s%nEntrega:   %s%nTOTAL:     %s%n%nPago: %s (ref. %s)",
                f.getId(), f.getPedido().getId(), Formato.moneda(f.getSubtotal()),
                Formato.moneda(f.getDescuento()), Formato.moneda(f.getCostoEntrega()),
                Formato.moneda(f.getTotal()), f.getPago().getMedioPago(), f.getPago().getReferencia()));
        texto.setEditable(false);
        JOptionPane.showMessageDialog(this, texto, "Compra exitosa", JOptionPane.INFORMATION_MESSAGE);
    }

    private void refrescar() {
        sesion.setClienteFrecuente(chkFrecuente.isSelected());
        sesion.setCupon(campoCupon.getText());
        cargarCatalogo();
        cargarCarrito();
        cargarPedidos();
        StringBuilder sb = new StringBuilder();
        ctx.getBandeja().getNotificaciones(sesion.getCliente().getId())
                .forEach(n -> sb.append('[').append(HORA.format(n.fecha())).append("] ")
                        .append(n.mensaje()).append('\n'));
        areaNotificaciones.setText(sb.length() == 0 ? "Sin notificaciones." : sb.toString());
    }

    private void cargarCatalogo() {
        modeloCatalogo.setRowCount(0);
        String filtro = (String) filtroCategoria.getSelectedItem();
        List<Producto> productos = filtro == null || filtro.equals("Todas")
                ? ctx.getProductos().findAll()
                : ctx.getProductos().findByCategoria(Categoria.valueOf(filtro));
        for (Producto p : productos) {
            modeloCatalogo.addRow(new Object[] {p.getId(), p.getNombre(), p.getCategoria(),
                    Formato.moneda(p.getPrecio()), Formato.stock(p), Formato.atributos(p)});
        }
    }

    private void cargarCarrito() {
        ResumenCompra r = sesion.resumen((Entrega) comboEntrega.getSelectedItem());
        modeloCarrito.setRowCount(0);
        for (ResumenCompra.Linea l : r.lineas()) {
            modeloCarrito.addRow(new Object[] {l.productoId(), l.descripcion(), l.cantidad(),
                    Formato.moneda(l.precioUnitario()), Formato.moneda(l.subtotal())});
        }
        areaResumen.setText(String.format("Subtotal:   %s%nDescuento: -%s  %s%nEntrega (%s): %s%nTOTAL:      %s",
                Formato.moneda(r.subtotal()), Formato.moneda(r.descuento()),
                r.descuentosAplicados().isEmpty() ? "" : r.descuentosAplicados(),
                r.modalidadEntrega(), Formato.moneda(r.costoEntrega()), Formato.moneda(r.total())));
    }

    private void cargarPedidos() {
        facturasMostradas = sesion.historial();
        modeloPedidos.setRowCount(0);
        for (Factura f : facturasMostradas) {
            modeloPedidos.addRow(new Object[] {f.getPedido().getId().substring(0, 8), Formato.moneda(f.getTotal()),
                    f.getPago().getMedioPago(), ctx.getSeguimiento().consultarEstado(f.getPedido().getId())});
        }
    }

    // --------------------------------------------------------------- helpers

    private Set<Extra> extrasMarcados() {
        Set<Extra> extras = EnumSet.noneOf(Extra.class);
        if (chkGarantia.isSelected()) extras.add(Extra.GARANTIA);
        if (chkEmpaque.isSelected()) extras.add(Extra.EMPAQUE);
        if (chkExpress.isSelected()) extras.add(Extra.EXPRESS);
        return extras;
    }

    private String idSeleccionado(JTable tabla) {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            throw new IllegalArgumentException("Selecciona una fila de la tabla");
        }
        return (String) tabla.getValueAt(fila, 0);
    }

    private void accion(Runnable r) {
        try {
            r.run();
        } catch (IllegalArgumentException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Aviso", JOptionPane.WARNING_MESSAGE);
            refrescar();
        }
    }

    private void info(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    private static DefaultTableModel modelo(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }
}
