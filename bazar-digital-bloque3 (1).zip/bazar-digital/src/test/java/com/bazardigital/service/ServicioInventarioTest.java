package com.bazardigital.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bazardigital.domain.factory.FabricaProductoFisico;
import com.bazardigital.domain.model.Carrito;
import com.bazardigital.domain.model.Categoria;
import com.bazardigital.domain.model.Cliente;
import com.bazardigital.domain.model.EntregaRetiro;
import com.bazardigital.domain.model.Pedido;
import com.bazardigital.domain.model.Producto;
import com.bazardigital.domain.observer.BandejaNotificaciones;
import com.bazardigital.domain.observer.EstadoPedido;
import com.bazardigital.domain.observer.EventoStock;
import com.bazardigital.domain.observer.ObservadorAlertaStock;
import com.bazardigital.domain.observer.ObservadorEstadoPedido;
import com.bazardigital.repository.InMemoryProductoRepository;

class ServicioInventarioTest {
    private final Cliente ana = new Cliente("C1", "Ana", "ana@example.com");
    private InMemoryProductoRepository productos;
    private BandejaNotificaciones bandeja;
    private ServicioInventario inventario;
    private Producto agotado;
    private Producto camisa;

    @BeforeEach
    void preparar() {
        productos = new InMemoryProductoRepository();
        bandeja = new BandejaNotificaciones();
        inventario = new ServicioInventario(productos, new ObservadorAlertaStock(bandeja));
        agotado = new FabricaProductoFisico(Categoria.TECNOLOGIA).crearProducto("X1", "Reloj", "Reloj", 1000, 0);
        camisa = new FabricaProductoFisico(Categoria.ROPA).crearProducto("X2", "Camisa", "Camisa", 500, 5);
        productos.save(agotado);
        productos.save(camisa);
    }

    @Test
    void reabastecerUnProductoAgotadoDisparaLaAlertaALosSuscritos() {
        inventario.suscribirAlertaStock(ana, "X1");
        assertTrue(bandeja.getNotificaciones().isEmpty());

        inventario.reabastecer("X1", 4);

        assertEquals(4, inventario.consultarStock("X1"));
        assertEquals(1, bandeja.getNotificaciones("C1").size());
    }

    @Test
    void noSePuedeSuscribirAUnProductoConStock() {
        assertThrows(IllegalArgumentException.class, () -> inventario.suscribirAlertaStock(ana, "X2"));
    }

    @Test
    void agotarseNoNotificaPeroLosObservadoresExternosRecibenElEvento() {
        List<EventoStock> eventos = new ArrayList<>();
        inventario.suscribir(eventos::add);

        inventario.ajustarStock("X2", 0);

        assertEquals(1, eventos.size());
        assertEquals(5, eventos.get(0).stockAnterior());
        assertEquals(0, eventos.get(0).stockNuevo());
        assertTrue(bandeja.getNotificaciones().isEmpty());
        assertTrue(inventario.productosAgotados().contains(camisa));
    }

    @Test
    void descontarPedidoEsTodoONada() {
        Pedido ok = new Pedido("P1", ana, List.of(camisa, camisa), new EntregaRetiro());
        inventario.descontarPedido(ok);
        assertEquals(3, camisa.getStock());

        Pedido excede = new Pedido("P2", ana, List.of(camisa, camisa, camisa, camisa), new EntregaRetiro());
        assertThrows(IllegalArgumentException.class, () -> inventario.descontarPedido(excede));
        assertEquals(3, camisa.getStock());
    }

    @Test
    void verificarDisponibilidadDetectaCarritosQueSuperanElStock() {
        Carrito carrito = new Carrito();
        carrito.agregar(camisa, 3);
        carrito.agregar(camisa, 3);
        assertThrows(IllegalArgumentException.class, () -> inventario.verificarDisponibilidad(carrito));
        assertEquals(5, camisa.getStock());
    }

    @Test
    void seguimientoPublicaCadaTransicionYRechazaLasInvalidas() {
        ServicioSeguimientoPedidos seguimiento = new ServicioSeguimientoPedidos();
        seguimiento.suscribir(new ObservadorEstadoPedido(bandeja));
        Pedido pedido = new Pedido("PED-0001", ana, List.of(camisa), new EntregaRetiro());
        seguimiento.registrar(pedido);

        seguimiento.cambiarEstado("PED-0001", EstadoPedido.PAGADO);
        seguimiento.cambiarEstado("PED-0001", EstadoPedido.EN_PREPARACION);

        assertEquals(EstadoPedido.EN_PREPARACION, seguimiento.consultarEstado("PED-0001"));
        assertEquals(2, bandeja.getNotificaciones("C1").size());
        assertThrows(IllegalStateException.class,
                () -> seguimiento.cambiarEstado("PED-0001", EstadoPedido.ENTREGADO));
        assertEquals(2, bandeja.getNotificaciones("C1").size());
        assertThrows(IllegalArgumentException.class,
                () -> seguimiento.cambiarEstado("NO-EXISTE", EstadoPedido.PAGADO));
    }
}
