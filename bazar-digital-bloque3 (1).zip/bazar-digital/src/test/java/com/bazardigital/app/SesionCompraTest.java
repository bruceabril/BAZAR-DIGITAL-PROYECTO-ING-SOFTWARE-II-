package com.bazardigital.app;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EnumSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.bazardigital.app.SesionCompra.Entrega;
import com.bazardigital.app.SesionCompra.Extra;
import com.bazardigital.app.SesionCompra.MedioPago;
import com.bazardigital.domain.model.Cliente;
import com.bazardigital.domain.observer.EstadoPedido;

/** Prueba de integración del flujo completo que usan la consola y la GUI. */
class SesionCompraTest {
    private final ContextoBazar ctx = new ContextoBazar();
    private final SesionCompra sesion = new SesionCompra(ctx, new Cliente("C1", "Ana", "ana@example.com"));

    @Test
    void compraCompletaDescuentaStockRegistraHistorialYNotifica() {
        sesion.agregar("R001", 2, Set.of());
        ResumenCompra resumen = sesion.resumen(Entrega.DOMICILIO);
        assertEquals(110000, resumen.subtotal());
        assertEquals(5500, resumen.descuento()); // temporada 5%
        assertEquals(10000, resumen.costoEntrega());

        var factura = sesion.pagar(Entrega.DOMICILIO, MedioPago.TRANSFERENCIA, "REF-1");

        assertEquals(resumen.total(), factura.getTotal());
        assertEquals(18, ctx.getInventario().consultarStock("R001"));
        assertTrue(sesion.getCarrito().estaVacio());
        assertEquals(1, sesion.historial().size());
        assertEquals(EstadoPedido.PAGADO, ctx.getSeguimiento().consultarEstado(factura.getPedido().getId()));
        assertEquals(1, ctx.getBandeja().getNotificaciones("C1").size());
    }

    @Test
    void extrasSeReflejanEnElPrecio() {
        sesion.agregar("R001", 1, EnumSet.of(Extra.GARANTIA, Extra.EMPAQUE, Extra.EXPRESS));
        // 55.000 + 10% garantía (5.500) + 5.000 + 12.000
        assertEquals(77500, sesion.resumen(Entrega.RETIRO).subtotal());
    }

    @Test
    void pagoRechazadoNoDescuentaStockNiVaciaElCarrito() {
        sesion.agregar("R001", 1, Set.of());
        assertThrows(IllegalArgumentException.class,
                () -> sesion.pagar(Entrega.DOMICILIO, MedioPago.TARJETA, "4111 1111 1111 0000"));
        assertEquals(20, ctx.getInventario().consultarStock("R001"));
        assertEquals(1, sesion.getCarrito().getCantidadTotal());
    }

    @Test
    void productoDigitalNoAdmiteExtrasNiContraEntrega() {
        assertThrows(IllegalArgumentException.class, () -> sesion.agregar("D001", 1, Set.of(Extra.EMPAQUE)));
        sesion.agregar("D001", 1, Set.of());
        assertEquals("Entrega digital", sesion.resumen(Entrega.DOMICILIO).modalidadEntrega());
        assertThrows(IllegalArgumentException.class,
                () -> sesion.pagar(Entrega.DOMICILIO, MedioPago.CONTRA_ENTREGA, null));
    }

    @Test
    void productoAgotadoNoSePuedeAgregarYLaAlertaFuncionaDePuntaAPunta() {
        assertThrows(IllegalArgumentException.class, () -> sesion.agregar("T002", 1, Set.of()));
        ctx.getInventario().suscribirAlertaStock(sesion.getCliente(), "T002");

        ctx.getInventario().reabastecer("T002", 3);

        assertEquals(1, ctx.getBandeja().getNotificaciones("C1").size());
        sesion.agregar("T002", 1, Set.of());
    }

    @Test
    void cuponYClienteFrecuenteSeEvaluanConLasReglasDeAcumulabilidad() {
        sesion.agregar("R001", 1, Set.of());
        sesion.setClienteFrecuente(true);
        sesion.setCupon(SesionCompra.CUPON_VALIDO);
        ResumenCompra r = sesion.resumen(Entrega.RETIRO);
        // acumulables: temporada 5% + frecuente 5% = 10%; cupón no acumulable 10% no lo supera
        assertEquals(5500, r.descuento());
        assertEquals(2, r.descuentosAplicados().size());
    }
}
