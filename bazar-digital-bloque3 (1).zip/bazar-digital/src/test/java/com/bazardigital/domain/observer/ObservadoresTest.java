package com.bazardigital.domain.observer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.bazardigital.domain.model.Cliente;

class ObservadoresTest {
    private final Cliente ana = new Cliente("C1", "Ana", "ana@example.com");
    private final Cliente luis = new Cliente("C2", "Luis", "luis@example.com");

    @Test
    void sujetoNotificaATodosLosSuscritosYRespetaLaBaja() {
        Sujeto<String> sujeto = new Sujeto<>();
        List<String> a = new ArrayList<>();
        List<String> b = new ArrayList<>();
        Observador<String> obsA = a::add;
        Observador<String> obsB = b::add;
        sujeto.suscribir(obsA);
        sujeto.suscribir(obsB);

        sujeto.notificar("uno");
        sujeto.desuscribir(obsB);
        sujeto.notificar("dos");

        assertEquals(List.of("uno", "dos"), a);
        assertEquals(List.of("uno"), b);
        assertEquals(1, sujeto.cantidadObservadores());
    }

    @Test
    void sujetoNoDuplicaSuscripcionesYUnObservadorFallidoNoBloqueaAlResto() {
        Sujeto<String> sujeto = new Sujeto<>();
        List<String> recibidos = new ArrayList<>();
        Observador<String> roto = e -> { throw new IllegalStateException("falla simulada"); };
        Observador<String> sano = recibidos::add;
        sujeto.suscribir(roto);
        sujeto.suscribir(roto);
        sujeto.suscribir(sano);

        sujeto.notificar("evento");

        assertEquals(2, sujeto.cantidadObservadores());
        assertEquals(List.of("evento"), recibidos);
    }

    @Test
    void alertaDeStockAvisaSoloCuandoUnProductoAgotadoSeReabastece() {
        BandejaNotificaciones bandeja = new BandejaNotificaciones();
        ObservadorAlertaStock alerta = new ObservadorAlertaStock(bandeja);
        alerta.registrarInteresado("T002", ana);
        alerta.registrarInteresado("T002", luis);

        alerta.actualizar(new EventoStock("T002", "Smartwatch", 5, 3));   // baja de stock
        alerta.actualizar(new EventoStock("T002", "Smartwatch", 3, 0));   // se agota
        assertTrue(bandeja.getNotificaciones().isEmpty());

        alerta.actualizar(new EventoStock("T002", "Smartwatch", 0, 10));  // reabastecimiento

        assertEquals(2, bandeja.getNotificaciones().size());
        assertEquals(1, bandeja.getNotificaciones("C1").size());
        assertTrue(bandeja.getNotificaciones("C1").get(0).mensaje().contains("Smartwatch"));
    }

    @Test
    void alertaDeStockAvisaUnaSolaVezYIgnoraOtrosProductos() {
        BandejaNotificaciones bandeja = new BandejaNotificaciones();
        ObservadorAlertaStock alerta = new ObservadorAlertaStock(bandeja);
        alerta.registrarInteresado("T002", ana);
        alerta.registrarInteresado("T002", ana); // repetido: cuenta una vez
        assertEquals(1, alerta.cantidadInteresados("T002"));

        alerta.actualizar(new EventoStock("OTRO", "Otro", 0, 5));
        assertTrue(bandeja.getNotificaciones().isEmpty());

        alerta.actualizar(new EventoStock("T002", "Smartwatch", 0, 5));
        alerta.actualizar(new EventoStock("T002", "Smartwatch", 0, 5));

        assertEquals(1, bandeja.getNotificaciones().size());
        assertFalse(alerta.estaRegistrado("T002", ana));
    }

    @Test
    void eventoStockIdentificaReabastecimientos() {
        assertTrue(new EventoStock("P", "P", 0, 1).esReabastecimiento());
        assertFalse(new EventoStock("P", "P", 2, 5).esReabastecimiento());
        assertFalse(new EventoStock("P", "P", 1, 0).esReabastecimiento());
    }

    @Test
    void observadorDePedidoNotificaElCambioDeEstadoAlCliente() {
        BandejaNotificaciones bandeja = new BandejaNotificaciones();
        new ObservadorEstadoPedido(bandeja).actualizar(
                new EventoPedido("12345678-aaaa", ana, EstadoPedido.PAGADO, EstadoPedido.ENVIADO));

        var notificacion = bandeja.getNotificaciones("C1").get(0);
        assertTrue(notificacion.mensaje().contains("#12345678"));
        assertTrue(notificacion.mensaje().contains("ENVIADO"));
    }

    @Test
    void estadoPedidoSoloPermiteTransicionesValidas() {
        assertTrue(EstadoPedido.CREADO.puedePasarA(EstadoPedido.PAGADO));
        assertFalse(EstadoPedido.CREADO.puedePasarA(EstadoPedido.ENTREGADO));
        assertTrue(EstadoPedido.ENTREGADO.siguientesPermitidos().isEmpty());
        assertThrows(NullPointerException.class, () -> new Sujeto<String>().suscribir(null));
    }
}
