# Bazar Digital — Documento de diseño

Proyecto de Ingeniería de Software II. Integrantes: Bruce Adrian Abril Ramírez, Santiago Caballero Díaz y Joseph David Gómez Argote.

Este documento describe la arquitectura, los cuatro patrones de diseño aplicados, las decisiones tomadas y las limitaciones conocidas. Los diagramas están en `docs/uml/` (fuente `.mmd` y render `.png`) y también se incluyen aquí en Mermaid.

## 1. Arquitectura

El sistema usa capas, con dependencias que apuntan hacia el dominio:

| Capa | Paquete | Responsabilidad |
|---|---|---|
| Interfaces | `ui.console`, `ui.gui` | Capturar entradas y mostrar resultados. No contienen reglas de negocio. |
| Aplicación | `app` | `ContextoBazar` (raíz de composición) y `SesionCompra` (caso de uso "comprar", compartido por ambas interfaces). |
| Servicios | `service` | `ServicioCarrito`, `ServicioCheckout`, `ServicioInventario`, `ServicioSeguimientoPedidos`. |
| Dominio | `domain.*` | Modelo, y los patrones Factory, Decorator, Strategy y Observer. |
| Persistencia | `repository` | Repositorios en memoria detrás de interfaces. |

**Decisión clave:** la consola y la GUI se construyen sobre `SesionCompra`. Así los extras, descuentos, el pago, el descuento de stock y las notificaciones se implementan una sola vez y se comportan igual en ambas interfaces (RNF01, RNF02).

![Diagrama de clases general](uml/02-clases-general.png)

## 2. Casos de uso

![Casos de uso](uml/01-casos-de-uso.png)

| Caso de uso | Requisito |
|---|---|
| CU1 Consultar catálogo por categoría | RF01 |
| CU2–CU3 Agregar al carrito con extras | RF02 |
| CU4 Descuentos y cupón | RF03 |
| CU5–CU6 Pago y factura | RF04, RF06 |
| CU7 Historial y estado de pedidos | RF06 |
| CU8–CU9 Alerta de stock y notificaciones | RF05 |
| CU10–CU11 Reabastecer / cambiar estado (simulados, sin roles) | RF05, RF06 |

## 3. Patrones de diseño

### 3.1 Strategy (comportamiento) — descuentos y pagos
**Problema:** las reglas de descuento y de pago cambian con frecuencia y cada una valida cosas distintas.
**Solución:** `EstrategiaDescuento` y `EstrategiaPago` encapsulan cada regla. `CalculadoraDescuentos` combina las estrategias acumulables (se suman sobre el subtotal original) con la mejor no acumulable. `ServicioCheckout` recibe la estrategia de pago por parámetro.
**Resultado:** agregar un nuevo descuento o medio de pago es crear una clase; el núcleo no cambia (RNF01).

![Strategy descuentos](uml/03a-patron-strategy-descuento.png)
![Strategy pagos](uml/03b-patron-strategy-pago.png)

### 3.2 Decorator (estructural) — extras del producto
**Problema:** garantía, empaque y envío express se combinan libremente; una subclase por combinación sería inviable.
**Solución:** `ProductoDecorado` extiende `Producto` y envuelve otro `Producto`, sumando su costo a `getPrecio()` y su nombre a `getDescripcion()`. `GarantiaExtendida`, `EmpaqueRegalo` y `EnvioExpress` se apilan en cualquier orden. `SesionCompra` los aplica al agregar al carrito.

![Decorator](uml/04-patron-decorator.png)

### 3.3 Factory Method (creacional) — productos y modalidades de entrega
`FabricaProducto` (física, digital, combo) crea productos sin que el cliente use `new` ni condicionales. `CreadorPedido` (domicilio, retiro, digital) crea pedidos con su `ModalidadEntrega`.

![Factory Method](uml/05-patron-factory-method.png)

### 3.4 Observer (comportamiento) — stock y estado de pedidos
**Problema:** el sistema debe avisar a clientes cuando un producto agotado vuelve a tener stock (RF05) y cuando cambia el estado de un pedido, sin que inventario o seguimiento conozcan a quién avisar ni cómo.

**Solución:**
- `Sujeto<E>` mantiene los observadores y notifica cada evento. Un observador que falla no interrumpe a los demás ni a la operación de negocio.
- `ServicioInventario` (publica `EventoStock`) y `ServicioSeguimientoPedidos` (publica `EventoPedido`) son los sujetos concretos.
- `ObservadorAlertaStock` registra clientes por producto agotado y avisa una sola vez cuando `stockAnterior == 0 && stockNuevo > 0`.
- `ObservadorEstadoPedido` notifica cada transición de estado.
- La entrega del mensaje se abstrae con `CanalNotificacion`; `BandejaNotificaciones` es el canal simulado.

![Observer](uml/06-patron-observer.png)

**Estados del pedido:** `CREADO → PAGADO | EN_PREPARACION → ENVIADO → ENTREGADO`, con `CANCELADO` posible hasta el envío. `EstadoPedido` valida las transiciones. Contra entrega pasa de `CREADO` directo a `EN_PREPARACION`, porque el cobro ocurre al entregar.

## 4. Flujo principal: compra

![Secuencia de compra](uml/07-secuencia-compra.png)

Orden de operaciones en `SesionCompra.pagar`:
1. Se verifica el stock de todo el carrito (sin modificar nada).
2. `ServicioCheckout.cerrarPedido` calcula descuentos y procesa el pago. Si el pago falla no se guarda el pedido ni se vacía el carrito.
3. Con el pago aprobado se descuenta el stock (todo o nada), se registra el pedido en el seguimiento y pasa a `PAGADO`. Cada cambio de stock y de estado dispara a sus observadores.

## 5. Trazabilidad de requisitos

| Requisito | Implementación | Estado |
|---|---|---|
| RF01 Catálogo por categorías | `ProductoRepository.findByCategoria`, `Formato.atributos` | Parcial: atributos solo de `ProductoFisico` (talla, marca), `ProductoDigital` y `ComboBazar` |
| RF02 Carrito y extras | `ServicioCarrito`, Decorator, `SesionCompra.agregar` | Completo |
| RF03 Descuentos y cupones | Strategy + `CalculadoraDescuentos` | Completo |
| RF04 Medios de pago | Strategy de pago | Completo (simulado) |
| RF05 Alerta de stock | Observer + `ServicioInventario.suscribirAlertaStock` | Completo |
| RF06 Historial y factura | `PedidoRepository`, `ServicioCheckout`, `SesionCompra.historial`, seguimiento | Completo; la factura no desglosa extras por línea |
| RNF01 Mantenibilidad | Cuatro patrones | Cumple |
| RNF02 Claridad | `ResumenCompra` muestra extras, descuentos aplicados, entrega y total antes de pagar | Cumple |
| RNF03 Consistencia de stock | Verificación previa y `descontarPedido` atómico | Cumple en el flujo de `SesionCompra`; `ServicioCheckout` por sí solo no toca el stock |
| RNF04 Tiempos | Cálculos en memoria, O(líneas) | Cumple |

## 6. Decisiones y limitaciones conocidas

- **Extras solo en productos físicos y combos.** Una garantía o un empaque no tiene sentido en un producto digital, así que `SesionCompra` lo rechaza.
- **Costos de los extras** (garantía 10 % del precio, empaque $5.000, express $12.000) y los porcentajes de descuento están definidos en `SesionCompra`; son fáciles de mover a configuración.
- **Dinero en `double`.** Es suficiente para esta simulación; un sistema real debería usar `BigDecimal` o enteros en centavos.
- **Decorator por herencia.** `ProductoDecorado` copia los datos del producto envuelto, por lo que un producto decorado deja de ser `instanceof ProductoFisico`. Para el flujo actual (precio, descripción, stock) es suficiente.
- **`EnvioExpress` se cobra por unidad** porque es un decorator de producto; en un negocio real sería un costo por pedido.
- **Pedido sin cantidades por línea.** `Pedido` guarda una lista plana de productos repetidos; la consola agrupa por producto al imprimir la factura.
- **Concurrencia.** `ServicioInventario` sincroniza sus operaciones, pero los repositorios en memoria no son seguros ante hilos; no es necesario para una aplicación de un usuario.
- **Sin persistencia.** Todo vive en memoria durante la ejecución.
- **Fuera de alcance** (según el documento de alcance): pasarelas de pago reales, rastreo GPS y panel multiusuario con roles. Las acciones "reabastecer" y "cambiar estado" son simulaciones para demostrar el Observer.

## 7. Pruebas

| Clase de prueba | Qué valida |
|---|---|
| `ObservadoresTest` | `Sujeto` (altas, bajas, duplicados, observador defectuoso), `ObservadorAlertaStock` (solo avisa al reabastecer, una sola vez, ignora otros productos), `ObservadorEstadoPedido`, transiciones de `EstadoPedido` |
| `ServicioInventarioTest` | Alerta de extremo a extremo, descuento todo o nada, verificación de carrito, seguimiento de pedidos |
| `SesionCompraTest` | Compra completa (stock, historial, notificación), extras, pago rechazado, digitales, acumulabilidad de cupón y cliente frecuente |
| Pruebas existentes | Fábricas, Decorator, descuentos, pagos, repositorio y checkout |
